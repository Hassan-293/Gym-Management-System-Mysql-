<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=>, initial-scale=1.0">
    <title> Gym Management System </title>
    <link rel="stylesheet" href="style.css">
</head>
<body  style="background-image:url('gym3.jpg');">




    <div class="container" >

    <nav class="navbar">
        <ul class= "nav-list" >

  <li><a href="#Gym Management System"></a><h2 style="color: #ffffff; font-size:28px;"><b>Gym Management System</b></h2></a></li>

            <li><a href="#Members"><b>Members</b></a></li>
            
            <li><a href="#Trainers"><b>Trainers</b></a></li>

            <li><a href="#About Us"><b>About Us</b></a></li>
            
            <li><a href="#Contact Us"><b>Contact Us</b></a></li>
       
           </div>
       
       
        </ul>
        </nav>




          
<form action="connect_payment.php" method="post">
<p style="font-size: 18px;color:#ffffff;  background-color:#000000;"> Enter the Payment Details  </p>  
<input type="number" name="Member_ID" id="Member ID" placeholder=" Enter Members ID ">
<input type="number" name="Trainer_ID" id="Trainer ID" placeholder="Enter Trainer ID">
 
<input type="number" name="Amount" id="Amount" placeholder="Enter the Amount">
<input type="text"  name="month" id="month" placeholder="Enter the month of payment">

<button  class="btn"    type="submit"><b> Submit </b></button>


    </form>
    </div>


    <script src="index.js"></script> 

</body>
</html>